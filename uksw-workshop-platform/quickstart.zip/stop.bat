@echo off
title SIA.Sat - Stopping...
color 0E

echo.
echo  ============================================================
echo   SIA.Sat - UKSW Workshop Platform
echo   Stopping all Docker containers...
echo  ============================================================
echo.

:: Check Docker is running
docker info >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo  [ERROR] Docker Desktop is not running.
    echo.
    pause
    exit /b 1
)

docker compose down --remove-orphans

if %errorlevel% neq 0 (
    color 0C
    echo.
    echo  [ERROR] Failed to stop containers.
    echo.
    pause
    exit /b 1
)

echo.
echo  ============================================================
echo   All containers stopped successfully.
echo   Database volumes are preserved.
echo.
echo   To also wipe the database, run:
echo     docker compose down -v
echo  ============================================================
echo.

echo  Press any key to close this window...
pause >nul
