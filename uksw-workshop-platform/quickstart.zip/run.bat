@echo off
title SIA.Sat - Starting...
color 0B

echo.
echo  ============================================================
echo   SIA.Sat - UKSW Workshop Platform
echo   Starting Docker containers...
echo  ============================================================
echo.

:: Check Docker is running
docker info >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo  [ERROR] Docker Desktop is not running!
    echo          Please start Docker Desktop and try again.
    echo.
    pause
    exit /b 1
)

:: Set placeholder so compose doesn't fail on missing NGROK token
if "%NGROK_AUTHTOKEN%"=="" set NGROK_AUTHTOKEN=DISABLED

echo  Building images and starting all services...
echo  (First run may take several minutes)
echo.

docker compose up --build -d --remove-orphans

if %errorlevel% neq 0 (
    color 0C
    echo.
    echo  [ERROR] docker compose up failed!
    echo          Run: docker compose logs   to see details.
    echo.
    pause
    exit /b 1
)

echo.
echo  Waiting for backend to become healthy...
echo.

set /a attempts=0
:healthcheck
set /a attempts+=1
if %attempts% gtr 24 (
    echo  [WARN] Backend health check timed out. It may still be starting.
    goto :done
)

for /f %%s in ('docker inspect --format={{.State.Health.Status}} sia-backend 2^>nul') do set STATUS=%%s

if "%STATUS%"=="healthy" (
    echo  Backend is healthy!
    goto :done
)

echo  ... status: %STATUS% (attempt %attempts%/24)
timeout /t 5 /nobreak >nul
goto :healthcheck

:done
echo.
echo  ============================================================
echo   Deploy Complete!
echo.
echo   Frontend  ->  http://localhost
echo   Backend   ->  http://localhost:8080
echo   Jaeger UI ->  http://localhost:8888
echo  ============================================================
echo.

:: Open browser
start "" "http://localhost"

echo  Press any key to close this window...
pause >nul
